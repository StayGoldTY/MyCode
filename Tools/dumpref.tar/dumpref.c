/*
 * dumpref.c
 * Dump the definition elements for a reference from a trigger.tgargs.
 *   dumpref(trigger.tgargs, switch) return text
 *   switch:
 *       0  constraint name
 *       1  child table
 *       2  parent table
 *       3  match type
 *       4  child columns (foreign)
 *       5  parent columns (primary)
 **/

#include <stdio.h>
#include "postgres.h"      /* for char16, etc. */
#include "utils/palloc.h"  /* for palloc() */
#include "utils/elog.h"    /* for elog() */

text * dumpref(bytea *pBuffer, int2 iSwitch);


text *
dumpref(bytea *pBuffer, int2 iSwitch)
{
   char  *ptr = VARDATA(pBuffer);
   int32  left = VARSIZE(pBuffer) - VARHDRSZ;
   text  *ret;
   int   i;

   /* Check arguments */
   if (iSwitch < 0 || iSwitch > 5)
   {
      elog(NOTICE, "dumpref: invalid switch value %d", iSwitch);
      goto error_exit;
   }
   
   /* Skip first fields when needed */
   for (i=0; i<iSwitch && i<4; i++)
   {
      while (*ptr && (left > 0))
      {
         ++ptr; --left;
      }
      /* skip nul-separator */
      ++ptr; --left;
   }

   /* Directly returns the name for the first values of iSwitch */
   if ((left > 0) && (iSwitch < 4))
   {
      int len,buflen;
      char *pWork;
      for (len=0,pWork=ptr; len<left && *pWork; ++len,++pWork) ;
      buflen = len + VARHDRSZ;
      ret = (text*)palloc(buflen);
      memset(ret, 0, buflen);
      VARSIZE(ret) = buflen;
      memcpy(VARDATA(ret), ptr, len);
      return ret;
   }

   /*  Build the list of primary/foreign columns */
   if ((left > 0) && (iSwitch == 4 || iSwitch == 5))
   {
      char *buffer = malloc(left+1);
      char *pWork = buffer;
      int keep = (iSwitch == 4) ? 1 : 0;
      int len,buflen;
      while (left > 0)
      {
         /* pass over one name */
         while (*ptr && left)
         {
            if (keep)
               *pWork++ = *ptr++;
            else
               ptr++;
            --left;
         }
         /* skip the nul and get ready for the next name */
         ++ptr; --left;
         /* switch the toggle */
         keep = !keep;
         /* if the next name is kept, we might need a comma separator */
         if (keep && (left > 1) && (pWork != buffer))
            *pWork++ = ',';
      }
      *pWork = '\0';
      len = strlen(buffer);
      buflen = len + VARHDRSZ;
      ret = (text*)palloc(buflen);
      memset(ret, 0, buflen);
      VARSIZE(ret) = buflen;
      memcpy(VARDATA(ret), buffer, len);
      free(buffer);
      return ret;
   }

error_exit:
   /* who do you say NULL? */
   ret = palloc(VARHDRSZ);
   memset(ret, 0, VARHDRSZ);
   VARSIZE(ret) = VARHDRSZ;
   return ret;
}
