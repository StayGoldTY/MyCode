select dumpref(tgargs,0) as constraint_name,
       dumpref(tgargs,1) as child_table,
       dumpref(tgargs,2) as parent_table,
       dumpref(tgargs,3) as match_condition,
       dumpref(tgargs,4) as foreign_keys,
       dumpref(tgargs,5) as primary_keys
from pg_trigger;
